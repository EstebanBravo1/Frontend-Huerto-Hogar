import {supabase} from '../lib/supabase'

export const productsLoader = async()=>{
  const {data: productos, error} = await supabase
    .from('productos')
    .select(`
      *,
      categorias(nombre),
      recetas(*)    
    `)
    .eq('activo', true)


  if (error){
    throw new Error('Error cargando productos: '+ error.message)
  }

  return {productos}

}













/*
export async function productsLoader() {
  // Simulamos una llamada a API con delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        productos: productos
      });
    }, 800); // 800ms de delay para simular latencia de red
  });
}
*/