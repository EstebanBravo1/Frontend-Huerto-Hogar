import { supabase } from '../lib/supabase'

export async function productDetailLoader({ params }) {
    // Buscar producto específico por código
    console.log('params.id', params.id);
    const { data: producto, error } = await supabase
        .from('productos')
        .select('*')
        .eq('codigo', params.id)
        .eq('activo', true)
        .single()
         // .single() para obtener un solo resultado

    if (error || !producto) {
        throw new Response("Producto no encontrado", { status: 404 });
    }

    return { producto };
}